class RemoveTileFromBooks < ActiveRecord::Migration[7.0]
  def change
    remove_column :books, :tile, :string
  end
end
