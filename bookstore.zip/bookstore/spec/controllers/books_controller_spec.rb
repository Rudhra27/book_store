require "rails_helper"
module Api
    module V1
        RSpec.describe Api::V1::BooksController, type: :controller do
            it 'subset with max limit of 1' do
                expect(Book).to receive(:limit).with(100).and_call_original
                get :index, params: {limit:999}

            end

            context 'missing authorization header' do
                it 'returns unauthorized error' do
                
                    post :create, params: {}
                    
                    expect(response).to have_http_status(:unauthorized)
                end
            end

            describe 'DELETE destroy' do
                context 'missing authorization header' do
                    it 'returns unauthorized error' do          
                        delete :destroy, params: {id: 1}
                        
                        expect(response).to have_http_status(:unauthorized)
                    end
                end
            end
            
        end
    end
end


