require 'rails_helper'

RSpec.describe 'Book', type: :model do
    let!(:tile2) {FactoryBot.create(:tile,name: 'And Then There were None', genre: 'Thriller', total_pages: '450', copies_sold: '50')}
    subject {
        book = Book.create(tile: tile2, author: "Lorem ipsum",cost: 800)
      #described_class.new(tile: "Anything",
       #                   author: "Lorem ipsum",
       #                  cost: 800)
    }
   
    it "is valid with valid attributes" do     
        expect(subject).to be_valid
    end
    it "is not valid without a title" do
    
        subject.tile = nil
        expect(subject).to_not be_valid
    end
    
    it "is not valid without a author" do
       
        subject.author = nil
        expect(subject).not_to be_valid
    end
    
    it "is not valid without a cost" do
       
        subject.cost = nil
        expect(subject).to_not be_valid
    end
   
end

describe 'Books API',type: :request do
    let!(:tile1) {FactoryBot.create(:tile,name: 'Happy', genre: 'comedy', total_pages: '400', copies_sold: '25')}
    let!(:tile2) {FactoryBot.create(:tile,name: 'And Then There were None', genre: 'Thriller', total_pages: '450', copies_sold: '50')}

    describe 'GET /books' do
        before do
            FactoryBot.create(:book, tile: tile1, author: 'xyz', cost: 400)
            FactoryBot.create(:book, tile: tile2, author: 'xyz', cost: 400)
        end

        it 'return all books' do
            get '/api/v1/books'

            expect(response).to have_http_status(:success)
            expect(response_body.size).to_not eq(0)          
            expect(response_body).to eq(
                [
                    {
                        "id" => 1,
                        "author" => 'xyz',
                        "cost" => 400,
                        "tile_name" => 'Happy',
                        "genre" => 'comedy',
                        "copies_sold" => 25,
                        "total_pages" => 400
                    },
                    {
                        "id" => 2,
                        "author" => 'xyz',
                        "cost" => 400,
                        "tile_name" => 'And Then There were None',
                        "genre" => 'Thriller',
                        "copies_sold" => 50,
                        "total_pages" => 450
                    }
                ]
            )
        end
        it 'returns a subset of books based on limit' do
            get '/api/v1/books', params: {limit:1}

            expect(response).to have_http_status(:success)
            expect(response_body.size).to eq(1)          
            expect(response_body).to eq(
                [
                    {
                        "id" => 1,
                        "author" => 'xyz',
                        "cost" => 400,
                        "tile_name" => 'Happy',
                        "genre" => 'comedy',
                        "copies_sold" => 25,
                        "total_pages" => 400
                    }
                ]
            )
        end  
        it 'returns a subset of books based on limit and offset' do  
            get '/api/v1/books', params: {limit:1, offset:1}

            expect(response).to have_http_status(:success)
            expect(response_body.size).to eq(1)          
            expect(response_body).to eq(
                [{
                    "id" => 2,
                    "author" => 'xyz',
                    "cost" => 400,
                    "tile_name" => 'And Then There were None',
                    "genre" => 'Thriller',
                    "copies_sold" => 50,
                    "total_pages" => 450
                }
                ]
            )  
        end
       
    end 

    describe 'POST /books' do
        
        let!(:user) {FactoryBot.create(:user,username: 'BookShop2022', password: 'HappyReading')}
        let!(:token) {AuthenticationTokenService.encode(user.id)}
       # let!(:tile2) {FactoryBot.create(:tile,name: 'And Then There were None', genre: 'Thriller', total_pages: '450', copies_sold: '50')}
        subject {
            book: {author: 'Lois Lowry', cost: '600'},
            tile: {name: 'Happy', genre: 'comedy', total_pages: '400', copies_sold: '25'}
        }
        it 'create a book' do
            expect { 
                post '/api/v1/books', params: "#{subject}", headers: {"Authorization": "Bearer #{token}"} 
            }.to change(Book, :count).by(1)
            expect(response).to have_http_status(:created)
            #expect(Tile.count).to eq(1)

            expect(response_body).to eq(
                {
                    "id" => 1,
                    "author" => 'Lois Lowry',
                    "cost" => 600,
                    "tile_name" => 'Happy',
                    "genre" => 'comedy',
                    "copies_sold" => 25,
                    "total_pages" => 400
                }
            )
        end
       
    end
    describe 'DELETE /books/:tile' do

       let!(:book) {FactoryBot.create(:book, tile: tile2, author: 'xyz', cost: 400)}
       let!(:user) {FactoryBot.create(:user,username: 'BookShop2022', password: 'HappyReading')}
       let!(:token) {AuthenticationTokenService.encode(user.id)}
       it 'delete a book' do
        expect {delete "/api/v1/books/#{book.id}",
        headers: {"Authorization" => "Bearer #{token}"} 
        }.to change{Book.count}.from(1).to(0)
        expect(response).to have_http_status(:no_content)
       end
    end

end


