require 'rails_helper'
module Api
    module V1
        describe 'Authentication',type: :request do

            describe 'POST /authenticate' do
                let!(:user) {FactoryBot.create(:user, username: 'BookShop2022',  password: 'HappyReading')}
                it 'it authenticate the client' do
                    post '/api/v1/authenticate', params: {username: user.username, password: 'HappyReading'}
                    expect(response).to have_http_status(:created)
                    expect(response_body).to eq( 'token' => 'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxfQ.DiPWrOKsx3sPeVClrm_j07XNdSYHgBa3Qctosdxax3w') 
                end

                it 'returns error when username is missing' do
                    post '/api/v1/authenticate', params: { password: 'HappyReading'}
                    expect(response).to have_http_status(:bad_request)
                    expect(response_body).to eq( {'error' => 'param is missing or value is empty :username'}) 
                end

                it 'returns error when password is missing' do
                    post '/api/v1/authenticate', params: {username: 'BookShop2022'}
                    expect(response).to have_http_status(:bad_request)
                    expect(response_body).to eq( {'error' => 'param is missing or value is empty :password'}) 
                end
                it 'returns error when password is incorrect' do
                    post '/api/v1/authenticate', params: {username: user.username, password: 'incorrect'}
                    expect(response).to have_http_status(:unauthorized)
                end
            end

        end
    end
end