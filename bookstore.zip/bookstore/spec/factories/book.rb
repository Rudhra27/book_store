FactoryBot.define do

    factory :book do
    
    end
end