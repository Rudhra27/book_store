FactoryBot.define do
  factory :tile do
   
  end
end
