class Book < ApplicationRecord
    validates :author, presence: true, length: {minimum: 3}
    #validates :tile, presence: true, uniqueness: true, length: {minimum: 3}
    validates :cost, presence: true, numericality: {greater_than: 0 }

    belongs_to :tile
end
