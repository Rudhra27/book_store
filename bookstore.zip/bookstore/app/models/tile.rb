class Tile < ApplicationRecord
    has_one :author, class_name: "books"
end
