#include AbstractController::Rendering
require "#{Rails.root}/app/representers/create_representer.rb"
class UpdateSkuJob < ApplicationJob
  queue_as :default
  def perform(tile_params,book_params)
    tile = Tile.create!(tile_params) 
    book = Book.new(book_params.merge(tile_id: tile.id)) 
    if book.save
      return book
      #render json: CreateRepresenter.new(book).as_json, status: :created
    else
      render json: book.errors, status: 422
    end
    #uri = URI('http://localhost:4567/update_sku')
    #req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json') 
    #req.body = {sku: '123', name: book_name}.to_json
    #res = Net::HTTP.start(uri.hostname, uri.port) do |http|
     # http.request(req)
    #end 
  end
end
