class CreateRepresenter
    #include Representable::JSON

    def initialize(book)
        @book = book
    end

    def as_json
            {
                id: book.id,
                author: book.author,
                cost: book.cost,
                tile_name: book.tile.name,
                genre: book.tile.genre,
                copies_sold: book.tile.copies_sold,
                total_pages: book.tile.total_pages
            }
    end
    private

    attr_reader :book
end