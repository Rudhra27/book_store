class BooksRepresenter 

    #include Representable::JSON

    def initialize(books)
        @books = books
    end

    def as_json
        books.map do |book|
            {
                id: book.id,
                author: book.author,
                cost: book.cost,
                tile_name: book.tile.name,
                genre: book.tile.genre,
                copies_sold: book.tile.copies_sold,
                total_pages: book.tile.total_pages
            }

        end
    end
    private

    attr_reader :books

end