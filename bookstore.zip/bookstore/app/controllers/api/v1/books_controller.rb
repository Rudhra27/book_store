require 'net/http'
module Api
  module V1
  
    #require '/representers/books_representer.rb'
    require "#{Rails.root}/app/representers/create_representer.rb"
    require "#{Rails.root}/app/representers/books_representer.rb"
    class BooksController < ApplicationController
      include ActionController::HttpAuthentication::Token

      before_action :authenticate_user, only: [:create, :destroy]
      def index
        books = Book.limit(limit).offset(params[:offset]) 
        render json: BooksRepresenter.new(books).as_json
      end
      def create
        job(tile_params,book_params)          
      end

      def destroy
        Book.find(params[:id]).destroy!
        head :no_content
      end

      private

      def authenticate_user
        # Authorization: Bearer <token>
        token, _options = token_and_options(request)
        user_id = AuthenticationTokenService.decode(token)
        User.find(user_id)
       rescue ActiveRecord::RecordNotFound, JWT::DecodeError
        render status: :unauthorized
      end
      def limit
        [params.fetch(:limit, 100).to_i,
         100 
        ].min
      end
      def tile_params
        params.require(:tile).permit(:name, :genre, :copies_sold, :total_pages)
      end

      def book_params
        params.require(:book).permit(:author, :cost)
      end

      def job(tile_params,book_params)      
        book =  UpdateSkuJob.perform_now(tile_params,book_params) 
        render json: CreateRepresenter.new(book).as_json, status: :created
      end
        
    end
  end
end
